/*
 *
 * Copyright (c) 2018-2030  KaBuDa
 *
 */

#import <UIKit/UIKit.h>

@interface KBDTestTool:NSObject

+ (void)start;

@end
